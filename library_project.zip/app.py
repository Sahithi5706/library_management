from flask import Flask, render_template, request, redirect, session
import mysql.connector
from datetime import date

app = Flask(__name__)
app.secret_key = "secret123"

db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="your_password",
    database="library_db"
)
cursor = db.cursor(dictionary=True)

@app.route("/", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]
        cursor.execute("SELECT * FROM users WHERE username=%s AND password=%s",(username, password))
        user = cursor.fetchone()
        if user:
            session["user_id"] = user["user_id"]
            session["role"] = user["role"]
            return redirect("/student" if user["role"]=="student" else "/librarian")
        return "Invalid credentials"
    return render_template("login.html")

@app.route("/student")
def student_dashboard():
    if session["role"] != "student":
        return redirect("/")
    return render_template("student_dashboard.html")

@app.route("/books")
def view_books():
    cursor.execute("SELECT category, GROUP_CONCAT(title SEPARATOR ', ') AS titles FROM books WHERE available=1 GROUP BY category")
    books = cursor.fetchall()
    return render_template("view_books.html", books=books)

@app.route("/mybooks")
def my_books():
    user_id = session["user_id"]
    cursor.execute("""
        SELECT books.title, books.author, borrowed_books.borrow_date
        FROM borrowed_books
        JOIN books ON books.book_id = borrowed_books.book_id
        WHERE borrowed_books.user_id = %s
    """, (user_id,))
    mybooks = cursor.fetchall()
    return render_template("borrow_list.html", mybooks=mybooks)

@app.route("/request", methods=["GET", "POST"])
def request_book():
    if request.method == "POST":
        user_id = session["user_id"]
        title = request.form["title"]
        message = request.form["message"]
        cursor.execute("INSERT INTO book_requests (user_id, book_title, message) VALUES (%s, %s, %s)",
                       (user_id, title, message))
        db.commit()
        return "Request submitted"
    return render_template("requests.html")

@app.route("/librarian")
def librarian_dashboard():
    if session["role"] != "librarian":
        return redirect("/")
    return render_template("librarian_dashboard.html")

@app.route("/students")
def all_students():
    cursor.execute("""
        SELECT borrowed_books.borrow_id, users.username, books.title, borrowed_books.borrow_date
        FROM borrowed_books
        JOIN users ON users.user_id = borrowed_books.user_id
        JOIN books ON books.book_id = borrowed_books.book_id
    """)
    records = cursor.fetchall()
    return render_template("borrow_list.html", mybooks=records)

@app.route("/addborrow", methods=["POST"])
def add_borrow():
    user_id = request.form["user_id"]
    book_id = request.form["book_id"]
    cursor.execute("INSERT INTO borrowed_books (user_id, book_id, borrow_date) VALUES (%s, %s, %s)",
                   (user_id, book_id, date.today()))
    cursor.execute("UPDATE books SET available=0 WHERE book_id=%s", (book_id,))
    db.commit()
    return redirect("/students")

@app.route("/delete/<int:id>")
def delete_record(id):
    cursor.execute("SELECT book_id FROM borrowed_books WHERE borrow_id=%s", (id,))
    book = cursor.fetchone()
    cursor.execute("DELETE FROM borrowed_books WHERE borrow_id=%s", (id,))
    cursor.execute("UPDATE books SET available=1 WHERE book_id=%s", (book["book_id"],))
    db.commit()
    return redirect("/students")

if __name__ == "__main__":
    app.run(debug=True)
